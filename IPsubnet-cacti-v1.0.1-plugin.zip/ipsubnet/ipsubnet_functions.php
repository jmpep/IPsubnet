<?php
/*
set tabstop=4 shiftwidth=4
 +------------------------------------------------------------------------------+
 | Copyright (C) plugin                                                         |
 |   like as Cacti GNU General Public License v2 or later (see Cacti licensing) |
 +------------------------------------------------------------------------------+
*/
function ipsubnet_log($message,$forcedebug=0) {
  global $config;
  $messagedate= date("Y-m-d H:i:s")." ".$message;
  // in cacti LOG
  // whenever possible with the cacti function
  if (($forcedebug==0) && (read_config_option("log_verbosity") != POLLER_VERBOSITY_NONE) ) {
     cacti_log($message,false,"SYSTEM");
  } else {
     $logdestination = read_config_option("log_destination");
     $logfile        = read_config_option("path_cactilog");
     if ($logfile == "") {
       $logfile = $config["base_path"] . "/log/cacti.log";
     }
     /* echo the data to the log (append) */
     $fp = @fopen($logfile, "a");
     if ($fp) {
          @fwrite($fp, $messagedate);
          fclose($fp);
     }
  }
}

function ipsubnet_header() {
  global $config;
  global $cacti_locale,$cacti_country,$cacti_textdomains,$lang2locale;
  $head="";
  if (version_compare($config['cacti_version'], '1.0.0') < 0) {
    $head=$head. '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />'."\n";
    $head=$head. '<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">'."\n";
    $head=$head. '<meta name="viewport" content="width=device-width, initial-scale=0.8, maximum-scale=2.0, minimum-scale=0.5">'."\n";
  }
  $head=$head.'     <!--[if lt IE 9]>'."\n";
  $head=$head.'     <script src="' . $config['url_path'] .'plugins/ipsubnet/js/html5shiv.min.js"></script>'."\n";
  $head=$head.'     <script src="' . $config['url_path'] .'plugins/ipsubnet/js/js/respond.min.js"></script>'."\n";
  $head=$head.'     <![endif]-->'."\n";
  $head=$head.'     <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/css/ie10-viewport-bug-workaround.css" rel="stylesheet">'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/css/bootstrap.min-no-icons.css" rel="stylesheet">'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/css/ipsubnet.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-WORLD.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-CS.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-EN.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-GB.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-US.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-FR.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-DE.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-IT.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-PL.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-RU.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-TR.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-ZH-HANS.css" rel="stylesheet" >'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/lang/languages-ZH.css" rel="stylesheet" >'."\n";
  $head=$head.'     <!-- using http://fontawesome.io licence GPL -->'."\n";
  $head=$head.'     <!-- using flags of https://github.com/lipis/flag-icon-css/ licence MIT-->'."\n";
  $head=$head.'     <link href="' . $config['url_path'] .'plugins/ipsubnet/fonts/flag-icon-css/css/flag-icon.css" rel="stylesheet" >'."\n";
  if (version_compare($config['cacti_version'], '1.0.0') < 0) {
     $head=$head.'      <link rel="stylesheet" href="' . $config['url_path'] .'plugins/ipsubnet/fonts/font-awesome/css/font-awesome.min.css">'."\n";
     $head=$head.'     <script src="' . $config['url_path'] .'plugins/ipsubnet/js/bootstrap.min.js"></script>'."\n";
     $head=$head.'     <script src="' . $config['url_path'] .'plugins/ipsubnet/ajax/libs/jquery/jquery.min.js"></script>'."\n";
  }
  if (version_compare($config['cacti_version'], '1.0.0') < 0) {
    $theme =  "classic";
    $lang = "en-us";
    $cacti_locale="en";
    $cacti_country="us";
  } else {
    if (function_exists('get_selected_theme') && (file_exists($config['base_path']."/plugins/ipsubnet/themes/".get_selected_theme()."/design.css")) ){
      $theme =  get_selected_theme();
    } else {
      $theme =  "classic";
    }
  }
  $head=$head."<link id='design' href='".$config['url_path']."plugins/ipsubnet/themes/".$theme."/design.css' type='text/css' rel='stylesheet'>\n";
  //$head=$head. '<SCRIPT>$(document).ready(function() {selectTheme("'.$theme.'") });</SCRIPT>'."\n";
  $lang = $cacti_locale.((($cacti_country!='')&&($cacti_country!=$cacti_locale))?('-'.$cacti_country):'');
  $head=$head. '<SCRIPT>';
  $head=$head. 'var tmpcacti_locale="'.$cacti_locale.'",tempcacti_country="'.$cacti_country.'";';
  $head=$head. 'var defaultlang="'.$lang.'";';
  $head=$head. 'var defaulttheme="'.$theme.'";'."\n";
  $head=$head. 'var defaultIP="192.168.0.1",defaultBits="24";'."\n";
//  $head=$head. '$(document).ready(function() {'."\n";
//  $head=$head. ' if (typeof(Storage) !== "undefined") {'."\n";
//  $head=$head. '  thelang= localStorage.getItem("lang"); '."\n";
//  $head=$head. '  if (thelang==null) { localStorage.setItem("lang",defaultlang); }'."\n";
//  $head=$head. "  $('body').attr('lang',thelang);"."\n";
//  $head=$head. '  thetheme= localStorage.getItem("theme"); '."\n";
//  $head=$head. '  if (thetheme==null) { localStorage.setItem("lang",defaulttheme); }'."\n";
//  $head=$head. ' } else {'."\n";
//  $head=$head. "  $('body').attr('lang','".$lang."');"."\n";
//  $head=$head. ' }'."\n";
//  $head=$head. '});'."\n";
  $head=$head. '</SCRIPT>'."\n";
  $head=$head.'     <SCRIPT src="' . $config['url_path'] .'plugins/ipsubnet/js/ipsubnet.js"></SCRIPT>'."\n";

  return $head;
}

