<?php
/*
 +------------------------------------------------------------------------------+
 | Copyright (C) plugin                                                         |
 |   like as Cacti GNU General Public License v2 or later (see Cacti licensing) |
 +------------------------------------------------------------------------------+
*/
chdir('../../');
$guest_account = true;
include_once("./include/auth.php");

if (version_compare($config['cacti_version'], '1.0.0') < 0) {
   include_once("./include/top_graph_header.php");
   include("./plugins/ipsubnet/ipsubnet-body.html");
   include_once("./include/bottom_footer.php");
} else {
   top_header();
   //general_header();
   include("plugins/ipsubnet/ipsubnet-body.html");
   bottom_footer();
}

?>
