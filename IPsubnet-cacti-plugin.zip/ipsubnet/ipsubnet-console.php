<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2005 Larry Adams                                          |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
*/
/*******************************************************************************

    Author ......... Jean-Michel Pepin plugin for Cacti (PEPJ in forum.cacti.net)
    Program ........ IP subnet calculator
    Purpose ........ http://cactiusers.org/forums/topic452.html

*******************************************************************************/

chdir('../../');
$guest_account = true;
include_once("./include/auth.php");

include_once("./include/top_header.php");
include("./plugins/ipsubnet/ipsubnet-body.html");
include_once("./include/bottom_footer.php");

?>
