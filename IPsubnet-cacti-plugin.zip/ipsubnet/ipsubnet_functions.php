<?php
/*
set tabstop=4 shiftwidth=4
 +------------------------------------------------------------------------------+
 | Copyright (C) plugin                                                         |
 |   like as Cacti GNU General Public License v2 or later (see Cacti licensing) |
 +------------------------------------------------------------------------------+
*/
function ipsubnet_log($message,$forcedebug=0) {
  global $config;
  $messagedate= date("Y-m-d H:i:s")." ".$message;
  // in cacti LOG
  // whenever possible with the cacti function
  if (($forcedebug==0) && (read_config_option("log_verbosity") != POLLER_VERBOSITY_NONE) ) {
     cacti_log($message,false,"SYSTEM");
  } else {
     $logdestination = read_config_option("log_destination");
     $logfile        = read_config_option("path_cactilog");
     if ($logfile == "") {
       $logfile = $config["base_path"] . "/log/cacti.log";
     }
     /* echo the data to the log (append) */
     $fp = @fopen($logfile, "a");
     if ($fp) {
          @fwrite($fp, $messagedate);
          fclose($fp);
     }
  }
}
