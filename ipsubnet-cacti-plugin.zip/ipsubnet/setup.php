<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2005 Larry Adams                                          |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
*/
/*******************************************************************************

    Author ......... Jean-Michel Pepin plugin for Cacti (PEPJ in forum.cacti.net)
    Program ........ IP subnet Calculator
    Version ........ 0.5
    Purpose ........ IP subnet Calculator

*******************************************************************************/

define("IPSUBNETVERSION", ".5");
define("IPSUBNETREALMproposition", "1055");

function plugin_init_ipsubnet() {
	global $plugin_hooks;
	$plugin_hooks['top_header_tabs']['ipsubnet'] = 'ipsubnet_show_tab';
	$plugin_hooks['top_graph_header_tabs']['ipsubnet'] = 'ipsubnet_show_tab';
	$plugin_hooks['config_arrays']['ipsubnet'] = 'ipsubnet_config_arrays';
	$plugin_hooks['draw_navigation_text']['ipsubnet'] = 'ipsubnet_draw_navigation_text';
}

/* plugin install - provides a generic PIA 2.x installer routine to register all plugin hook functions.
*/
function plugin_ipsubnet_install() {
        // api_plugin_register_realm ('ipsubnet', 'ipsubnet.php', 'Use IP subnet calculator', 1); //enable ipsubnet for admin
        api_plugin_register_hook('ipsubnet', 'top_header_tabs',       'ipsubnet_show_tab',             "setup.php");
        api_plugin_register_hook('ipsubnet', 'top_graph_header_tabs', 'ipsubnet_show_tab',             "setup.php");
        api_plugin_register_hook('ipsubnet', 'config_arrays',         'ipsubnet_config_arrays',        "setup.php");
        api_plugin_register_hook('ipsubnet', 'draw_navigation_text',  'ipsubnet_draw_navigation_text', "setup.php");
        /* uncomment if you need more hooks */
//       api_plugin_register_hook ('ipsubnet', 'config_settings', 'ipsubnet_config_settings', 'setup.php');
        api_plugin_register_hook('ipsubnet', 'top_graph_refresh',     'ipsubnet_top_graph_refresh',    "setup.php");
//       api_plugin_register_hook ('ipsubnet', 'console_after', 'ipsubnet_console_after', 'setup.php');
//       api_plugin_register_hook ('ipsubnet', 'api_device_save', 'ipsubnet_api_device_save', 'setup.php');
//       api_plugin_register_hook ('ipsubnet', 'device_action_array', 'ipsubnet_device_action_array', 'setup.php');
//       api_plugin_register_hook ('ipsubnet', 'poller_bottom', 'ipsubnet_poller_bottom', 'setup.php');
        ipsubnet_setup_table_new ();
}

/* plugin uninstall - a generic uninstall routine.  Right now it will do nothing as I
   If you don't want the tables removed from the system except let it empty. */
function plugin_ipsubnet_uninstall () {
        /* Do any extra Uninstall stuff here */
  //api_plugin_remove_realms ('ipsubnet');
}

function plugin_ipsubnet_check_config () {
        /* Here we will check to ensure everything is configured */
        ipsubnet_check_upgrade();
        return true;
}

function plugin_ipsubnet_upgrade () {
        /* Here we will upgrade to the newest version */
        ipsubnet_check_upgrade();
        return false;
}

function plugin_ipsubnet_version () {
        return ipsubnet_version();
}

function ipsubnet_check_upgrade () {
        global $config;

        $files = array('index.php', 'plugins.php', 'ipsubnet.php');
        if (isset($_SERVER['PHP_SELF']) && !in_array(basename($_SERVER['PHP_SELF']), $files)) {
                return;
        }

        $current = plugin_ipsubnet_version();
        $current = $current['version'];
        $old     = db_fetch_row("SELECT * FROM plugin_config WHERE directory='ipsubnet'");
        if (sizeof($old) && $current != $old["version"]) {
                /* if the plugin is installed and/or active */
                if ($old["status"] == 1 || $old["status"] == 4) {
                        /* re-register the hooks */
                        plugin_ipsubnet_install();

                        /* perform a database upgrade */
                        ipsubnet_database_upgrade();
                }

                /* update the plugin information */
                $info = plugin_ipsubnet_version();
                $id   = db_fetch_cell("SELECT id FROM plugin_config WHERE directory='ipsubnet'");
                db_execute("UPDATE plugin_config
                        SET name='" . $info["longname"] . "',
                        author='"   . $info["author"]   . "',
                        webpage='"  . $info["homepage"] . "',
                        version='"  . $info["version"]  . "'
                        WHERE id='$id'");
        }
}

function ipsubnet_database_upgrade () {
}

function ipsubnet_check_dependencies() {
        global $plugins, $config;

        return true;
}

function ipsubnet_setup_table_new () {
}

function ipsubnet_version () {
	return array( 'name' 	=> 'ipsubnet'
			,'version' 	=> IPSUBNETVERSION
			,'longname'	=> 'IP subnet Calculator IPv4 IPv6'
			,'author'	=> 'Jean-Michel Pepin'
			,'homepage'	=> 'http://cactiusers.org/forums/topic452.html'
			,'email'	=> ''
			,'url'		=> 'https://github.com/jmpep/IPsubnet/blob/master/IPsubnet-cacti-plugin.zip');
}

function ipsubnet_show_tab () {
  global $config, $user_auth_realms, $user_auth_realm_filenames;

  $realm_id2 = 0;

  /*---- Begin of the minimal functions needed ----*/
  if (isset($user_auth_realm_filenames{basename('ipsubnet.php')})) {
                $realm_id2 = $user_auth_realm_filenames{basename('ipsubnet.php')};
  }
  if ((db_fetch_assoc("select user_auth_realm.realm_id
        from user_auth_realm where user_auth_realm.user_id='" . $_SESSION["sess_user_id"] . "'
        and user_auth_realm.realm_id='$realm_id2'")) || (empty($realm_id2))) {

        if (substr_count($_SERVER["REQUEST_URI"], "ipsubnet.php")) {
                print '<a href="' . $config['url_path'] . 'plugins/ipsubnet/ipsubnet.php"><img src="' . $config['url_path'] . 'plugins/ipsubnet/images/tab_ipsubnet-green.gif" alt="ipsubnet" align="absmiddle" border="0"></a>';
        }else{
                print '<a href="' . $config['url_path'] . 'plugins/ipsubnet/ipsubnet.php"><img src="' . $config['url_path'] . 'plugins/ipsubnet/images/tab_ipsubnet.gif" alt="ipsubnet" align="absmiddle" border="0"></a>';
        }

  }
}

function ipsubnet_search_realms($therealmtitle,$therealmproposition) {
  global $user_auth_realms, $user_auth_realm_filenames;

  $search_realm=$therealmproposition;
  if (isset($user_auth_realms)) {
     $firstnotin=$therealmproposition;
     while (array_key_exists($firstnotin,$user_auth_realms)) {
           $firstnotin = $firstnotin + 1;
     }
     if (array_key_exists($therealmproposition,$user_auth_realms) && ($user_auth_realms[$therealmproposition]==$therealmtitle)) {
           $search_realm=$therealmproposition;
     } else {
       $search_realm=$firstnotin;
     }
  }
  return $search_realm;
}

function ipsubnet_config_arrays () {
   global $user_auth_realms, $menu,$user_auth_realm_filenames;

   $myrealmtitle   ='View IP subnet calculator';
   $newrealm=ipsubnet_search_realms($myrealmtitle,IPSUBNETREALMproposition);
   $user_auth_realms[$newrealm]=$myrealmtitle;
   $user_auth_realm_filenames['ipsubnet.php'] = $newrealm;
   $myrealmtitle2  ='View IP subnet calculator (console)';
   $newrealm2=ipsubnet_search_realms($myrealmtitle,IPSUBNETREALMproposition+1);
   $user_auth_realms[$newrealm2]=$myrealmtitle2;
   $user_auth_realm_filenames['ipsubnet-console.php'] = $newrealm2;

   $temp = $menu["Utilities"]['logout.php'];
   unset($menu["Utilities"]['logout.php']);
   $menu["Utilities"]['plugins/ipsubnet/ipsubnet-console.php'] = "IP subnet calculator";
   $menu["Utilities"]['logout.php'] = $temp;
}

function ipsubnet_draw_navigation_text ($nav) {
   $nav["ipsubnet.php:"] = array("title" => "ipsubnet calculator", "mapping" => "index.php:", "url" => "ipsubnet.php", "level" => "1");
   $nav["ipsubnet-console.php:"] = array("title" => "ipsubnet calculator", "mapping" => "index.php:", "url" => "ipsubnet-console.php", "level" => "1");
   return $nav;
}

function ipsubnet_api_device_save ($save) {
    return $save;
}

function ipsubnet_poller_bottom () {
	global $config;

}

function ipsubnet_config_settings () {
  global $tabs, $settings, $config, $user_auth_realms, $user_auth_realm_filenames;

} //end function


function ipsubnet_top_graph_refresh($refresh) {
  /* change the refresh time of your view. Here as example plgexample.php */
  /* plgexample_refresh is supposed to be one parameter of the setting */
  if ((basename($_SERVER['PHP_SELF']) != 'ipsubnet.php') && (basename($_SERVER['PHP_SELF']) != 'ipsubnet-console.php'))
          return $refresh;
  return '';
}

function ipsubnet_device_action_array($device_action_array) {
  $device_action_array['ipsubnet'] = 'IPsubnet';
  return $device_action_array;
}



?>
